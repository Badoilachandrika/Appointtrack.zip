// db.js
const mysql = require('mysql');

// Create the database connection
const connection = mysql.createConnection({
  host: 'localhost', // or your MySQL server host
  user: 'root', // replace with your MySQL username
  password: '1234', // replace with your MySQL password
  database: 'appointtrack' // replace with your database name
});

// Connect to the database
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to the database:', err.stack);
    return;
  }
  console.log('Connected to the database.');
});

module.exports = connection;