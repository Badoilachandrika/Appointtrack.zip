// server.js
const express = require('express');
const app = express();
const db = require('./config/db');  // Assuming db.js handles the database connection
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const PORT = process.env.PORT || 5000;

app.use(bodyParser.json()); // To handle JSON requests

// Sample route to check server status
app.get('/', (req, res) => {
  res.send('Server is running...');
});

// Route to register a new user
app.post('/register', (req, res) => {
  const { username, password } = req.body;

  // Hash password before saving
  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) {
      return res.status(500).json({ error: 'Error hashing password' });
    }

    // Insert into the database
    const query = 'INSERT INTO users (username, password) VALUES (?, ?)';
    db.query(query, [username, hashedPassword], (err, result) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }
      res.status(201).json({ message: 'User registered successfully!' });
    });
  });
});

// Route to login and issue a token
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  const query = 'SELECT * FROM users WHERE username = ?';
  db.query(query, [username], (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }

    if (result.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }

    // Compare password with hashed password
    bcrypt.compare(password, result[0].password, (err, isMatch) => {
      if (err) {
        return res.status(500).json({ error: 'Error comparing passwords' });
      }
      if (!isMatch) {
        return res.status(400).json({ error: 'Incorrect password' });
      }

      // Create a token for the user
      const token = jwt.sign({ userId: result[0].id }, 'your_jwt_secret', {
        expiresIn: '1h',
      });

      res.status(200).json({ message: 'Login successful', token });
    });
  });
});

// Route for creating appointments (requires authentication)
app.post('/appointments', (req, res) => {
  const { token } = req.headers;
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  jwt.verify(token, 'your_jwt_secret', (err, decoded) => {
    if (err) {
      return res.status(401).json({ error: 'Invalid or expired token' });
    }

    const { doctorName, appointmentDate, patientName } = req.body;
    const query =
      'INSERT INTO appointments (doctorName, appointmentDate, patientName, userId) VALUES (?, ?, ?, ?)';
    db.query(
      query,
      [doctorName, appointmentDate, patientName, decoded.userId],
      (err, result) => {
        if (err) {
          return res.status(500).json({ error: 'Database error' });
        }
        res.status(201).json({ message: 'Appointment created successfully!' });
      }
    );
  });
});

// Start the server
app.listen(PORT, () => {
  console.log('Server is running on port ${5000}');
});