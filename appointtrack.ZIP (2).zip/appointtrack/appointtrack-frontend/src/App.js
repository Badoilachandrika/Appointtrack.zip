import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from '.src/pages/Login';
import Register from '.src/pages/Register';
import Dashboard from '.src/pages/Dashboard';
import AddAppointment from '.src/pages/AddAppointment';
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Routes>
          <Route path="/add-appointment" element={<AddAppointment/>}/>
        </Routes>
      </Routes>
    </Router>
  );
}

export default App;