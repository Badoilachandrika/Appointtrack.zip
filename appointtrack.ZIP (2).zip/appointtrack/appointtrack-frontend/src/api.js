import axios from 'axios';

const API_URL = 'http://localhost:5000/api/appointments'; // Change to your backend URL

export const getAppointments = async () => {
    return await axios.get(API_URL);
};

export const addAppointment = async (appointment) => {
    return await axios.post(API_URL, appointment);
};

export const updateAppointment = async (id, appointment) => {
    return await axios.put(`${API_URL}/${id}`, appointment);
};

export const deleteAppointment = async (id) => {
    return await axios.delete(`${API_URL}/${id}`);
};