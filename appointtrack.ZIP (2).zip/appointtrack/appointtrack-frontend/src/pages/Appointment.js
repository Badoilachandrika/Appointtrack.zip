import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";

const API_URL = "http://localhost:5000/appointments"; // Adjust if your backend URL is different

const Appointments = () => {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [newAppointment, setNewAppointment] = useState({
    providerName: "",
    dateTime: "",
    reason: "",
  });

  useEffect(() => {
    fetchAppointments();
  }, []);

  // Fetch Appointments
  const fetchAppointments = async () => {
    const res = await fetch(API_URL, {
      headers: { Authorization: user.token },
    });
    const data = await res.json();
    setAppointments(data);
  };

  // Create New Appointment
  const addAppointment = async () => {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: user.token,
      },
      body: JSON.stringify(newAppointment),
    });

    if (res.ok) {
      fetchAppointments(); // Refresh list
      setNewAppointment({ providerName: "", dateTime: "", reason: "" });
    }
  };

  // Delete Appointment
  const deleteAppointment = async (id) => {
    await fetch(${API_URL}/${id}, {
      method: "DELETE",
      headers: { Authorization: user.token },
    });
    fetchAppointments();
  };

  return (
    <div>
      <h2>Appointments</h2>

      {/* Add Appointment Form */}
      <div>
        <input
          type="text"
          placeholder="Provider Name"
          value={newAppointment.providerName}
          onChange={(e) => setNewAppointment({ ...newAppointment, providerName: e.target.value })}
        />
        <input
          type="datetime-local"
          value={newAppointment.dateTime}
          onChange={(e) => setNewAppointment({ ...newAppointment, dateTime: e.target.value })}
        />
        <input
          type="text"
          placeholder="Reason"
          value={newAppointment.reason}
          onChange={(e) => setNewAppointment({ ...newAppointment, reason: e.target.value })}
        />
        <button onClick={addAppointment}>Add</button>
      </div>

      {/* Display Appointments */}
      <ul>
        {appointments.map((appointment) => (
          <li key={appointment._id}>
            {appointment.providerName} - {new Date(appointment.dateTime).toLocaleString()}
            <button onClick={() => deleteAppointment(appointment._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Appointments;
      