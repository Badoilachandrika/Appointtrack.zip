function AddAppointment() {
    const [formData, setFormData] = useState({ providerName: "", date: "", time: "", status: "Upcoming" });

    const handleSubmit = async (e) => {
        e.preventDefault();
        await axios.post("http://localhost:5000/api/appointments/add", formData);
        alert("Appointment added!");
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" placeholder="Provider Name" onChange={(e) => setFormData({ ...formData, providerName: e.target.value })} required />
            <input type="date" onChange={(e) => setFormData({ ...formData, date: e.target.value })} required />
            <input type="time" onChange={(e) => setFormData({ ...formData, time: e.target.value })} required />
            <button type="submit">Add Appointment</button>
        </form>
    );
}